// supabase functions deploy admin-reset-password
// Secrets required: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
//
// Called from the app's Admin > Staff accounts panel with:
//   Authorization: Bearer <the calling admin's access_token>
//   body: { staff_id, new_password? }

import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization") || "";
    const callerToken = authHeader.replace("Bearer ", "");
    if (!callerToken) return json({ error: "Missing Authorization header" }, 401);

    const callerClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await callerClient.auth.getUser(callerToken);
    if (userErr || !userData?.user) return json({ error: "Invalid session" }, 401);

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    const { data: callerProfile } = await admin
      .from("staff_profiles")
      .select("role")
      .eq("id", userData.user.id)
      .single();
    if (!callerProfile || callerProfile.role !== "admin") {
      return json({ error: "Only admins can reset passwords" }, 403);
    }

    const { staff_id, new_password } = await req.json();
    if (!staff_id) return json({ error: "staff_id is required" }, 400);
    const password = new_password || "changeme123";

    const { error: updateErr } = await admin.auth.admin.updateUserById(staff_id, { password });
    if (updateErr) return json({ error: updateErr.message }, 400);

    await admin.from("staff_profiles").update({ must_change_password: true }).eq("id", staff_id);

    return json({ ok: true, temp_password: password });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
