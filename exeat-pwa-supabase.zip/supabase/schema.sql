-- ============================================================
-- Kanton SHS Exeat Register — Supabase schema
-- Run this whole file once in the Supabase SQL editor
-- (Dashboard > SQL Editor > New query > paste > Run).
-- ============================================================

create extension if not exists pgcrypto;

-- ---------- houses ----------
create table if not exists houses (
  id   text primary key,
  name text not null
);
insert into houses (id, name) values
  ('Falcon','Falcon'), ('Eagle','Eagle'), ('Hawk','Hawk'), ('Osprey','Osprey')
on conflict (id) do nothing;

-- ---------- staff profiles (1:1 with auth.users) ----------
create table if not exists staff_profiles (
  id                    uuid primary key references auth.users(id) on delete cascade,
  name                  text not null,
  role                  text not null check (role in ('warden','gate','admin')),
  house_id              text references houses(id),
  gate_post             text,
  must_change_password  boolean not null default true,
  created_at            timestamptz not null default now()
);

create or replace function is_admin() returns boolean
language sql security definer stable as $$
  select exists(select 1 from staff_profiles where id = auth.uid() and role = 'admin');
$$;

-- ---------- app-wide config (single row) ----------
create table if not exists app_config (
  id                 int primary key default 1,
  max_per_semester   int not null default 3,
  semester_start     date not null default date_trunc('month', now())::date,
  escalation_hours   int not null default 12,
  constraint singleton check (id = 1)
);
insert into app_config (id) values (1) on conflict (id) do nothing;

-- ---------- blackout / restricted periods ----------
create table if not exists blackout_periods (
  id         uuid primary key default gen_random_uuid(),
  label      text not null,
  start_date date not null,
  end_date   date not null,
  created_at timestamptz not null default now()
);

-- ---------- exeat requests ----------
create sequence if not exists exeat_pass_no_seq;

create table if not exists exeat_requests (
  id                         uuid primary key default gen_random_uuid(),
  no                         int not null default nextval('exeat_pass_no_seq'),
  pass_id                    text,
  category                   text not null check (category in ('day','weekend','medical','emergency')),
  student_name               text not null,
  student_class              text,
  house_id                   text references houses(id),
  destination                text not null,
  reason                     text not null,
  depart_date                date not null,
  depart_time                time,
  return_date                date,
  return_time                time,
  parent_contact             text,
  contact_person             text,
  transport                  text,
  photo_url                  text,
  admin_override_requested   boolean not null default false,
  created_at                 timestamptz not null default now(),
  parent_approved_at         timestamptz,
  parent_auto_approved       boolean not null default false,
  warden_approved_at         timestamptz,
  warden_approved_by         text,
  admin_approved_at          timestamptz,
  admin_approved_by          text,
  denied_at                  timestamptz,
  denied_by                  text,
  deny_reason                text,
  info_requested_at          timestamptz,
  info_requested_by          text,
  info_comment               text,
  sign_out_at                timestamptz,
  sign_out_by                text,
  sign_in_at                 timestamptz,
  sign_in_by                 text
);

create index if not exists idx_requests_house on exeat_requests(house_id);
create index if not exists idx_requests_student on exeat_requests(student_name);

-- ---------- audit trail ----------
create table if not exists audit_log (
  id          uuid primary key default gen_random_uuid(),
  request_id  uuid not null references exeat_requests(id) on delete cascade,
  ts          timestamptz not null default now(),
  actor       text not null,
  action      text not null,
  note        text
);
create index if not exists idx_audit_request on audit_log(request_id);

-- ---------- notifications ----------
create table if not exists notifications (
  id                    uuid primary key default gen_random_uuid(),
  ts                    timestamptz not null default now(),
  audience_role         text not null check (audience_role in ('student','parent','warden','admin','gate')),
  audience_house        text,
  audience_student_name text,
  message               text not null,
  read                  boolean not null default false
);

-- ============================================================
-- Row Level Security
-- ============================================================
alter table houses enable row level security;
alter table staff_profiles enable row level security;
alter table app_config enable row level security;
alter table blackout_periods enable row level security;
alter table exeat_requests enable row level security;
alter table audit_log enable row level security;
alter table notifications enable row level security;

-- houses: read-only reference data
create policy "houses readable by all" on houses for select using (true);

-- staff_profiles: everyone can read (needed to resolve names/houses),
-- but only the row owner can touch their own row, and only via the
-- must_change_password flag. Creating/deleting staff accounts and
-- resetting someone else's password happens through the two Edge
-- Functions (service-role key), never via a public policy.
create policy "staff readable by all" on staff_profiles for select using (true);
create policy "staff can update own row" on staff_profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- app_config / blackout_periods: readable by all, writable by admins only
create policy "config readable by all" on app_config for select using (true);
create policy "config writable by admin" on app_config for update using (is_admin()) with check (is_admin());

create policy "blackout readable by all" on blackout_periods for select using (true);
create policy "blackout writable by admin" on blackout_periods for all using (is_admin()) with check (is_admin());

-- exeat_requests / audit_log / notifications: open read/write.
-- NOTE: students and parents are NOT authenticated in this app, so
-- these policies are intentionally permissive (same trust model as
-- a shared front-desk kiosk). Anyone with the app URL can read and
-- act on any record. That's fine for a small trusted school network;
-- before wider rollout, add real parent/student accounts and scope
-- these policies to auth.uid() the same way staff_profiles is scoped.
create policy "requests readable by all" on exeat_requests for select using (true);
create policy "requests insertable by all" on exeat_requests for insert with check (true);
create policy "requests updatable by all" on exeat_requests for update using (true) with check (true);

create policy "audit readable by all" on audit_log for select using (true);
create policy "audit insertable by all" on audit_log for insert with check (true);

create policy "notifications readable by all" on notifications for select using (true);
create policy "notifications insertable by all" on notifications for insert with check (true);
create policy "notifications updatable by all" on notifications for update using (true) with check (true);

-- ============================================================
-- Realtime: make sure these tables broadcast changes
-- ============================================================
alter publication supabase_realtime add table exeat_requests;
alter publication supabase_realtime add table audit_log;
alter publication supabase_realtime add table notifications;

-- ============================================================
-- Storage bucket for student photo IDs
-- ============================================================
insert into storage.buckets (id, name, public)
values ('exeat-photos', 'exeat-photos', true)
on conflict (id) do nothing;

create policy "photo upload by all" on storage.objects
  for insert with check (bucket_id = 'exeat-photos');
create policy "photo read by all" on storage.objects
  for select using (bucket_id = 'exeat-photos');

-- ============================================================
-- Done. Next: create staff Auth users (see SETUP.md) and insert
-- matching rows into staff_profiles with their real auth.users id.
-- ============================================================
